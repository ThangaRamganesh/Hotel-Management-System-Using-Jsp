package com.hotel.servlet;

import com.hotel.model.Room;
import com.hotel.util.DBConnection;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

public class FetchAvailableRoomsServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Room> availableRooms = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT * FROM room WHERE is_available = 1");
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Room room = new Room();
                room.setRoomId(rs.getInt("room_id"));
                room.setType(rs.getString("type"));
                room.setPrice(rs.getDouble("price"));
                availableRooms.add(room);
            }

            request.setAttribute("availableRooms", availableRooms);
            RequestDispatcher dispatcher = request.getRequestDispatcher("book_room.jsp");
            dispatcher.forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("customer_dashboard.jsp");
        }
    }
}
